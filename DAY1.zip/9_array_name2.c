﻿// 51 page
#include <stdio.h>

int main()
{
	int x[3] = { 1,2,3 };

	int (*p1)[3] = &x; 
	int* p2 = x;

}
