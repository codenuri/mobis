﻿// 10 page
#include <stdio.h>

// 전역변수와 file size
int x[10000];

int main()
{
	x[0] = 10;
}

