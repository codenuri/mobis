#include "chronometry.h"
#include <stdlib.h>
#include <string.h>

#define INPUT_COUNT 100000

// 1,2,3,4 ... 순차적으로 반환.. 사용자 입력 시뮬레이션
int get_input()
{
	static int num = 0;
	++num;

	if (num == INPUT_COUNT)
	{
		num = 0;
		return -1;
	}
	return num;
}
// ------------------------------------------

void ex1()
{

	// vector3.c 의 main 코드 복사
}

void ex2()
{

}
int main()
{
	CHRONOMETRY(ex1);
	CHRONOMETRY(ex2);
}



