﻿#include "chronometry.h"
#include <vector>
#include <list>
#include <stdlib.h>
#include <string.h>

#define INPUT_COUNT 1000000

int get_input()
{
	static int num = 0;
	++num;

	if (num == INPUT_COUNT)
	{
		num = 0;
		return -1;
	}
	return num;
}
//======================================

void using_cpp_vector()
{
	int n = 0;
	std::vector<int> c;
	
	while (1)
	{
		n = get_input();

		if (n == -1)
			break;

		c.push_back(n);
	}
}

void using_cpp_list()
{
	int n = 0;
	std::list<int> c; // 더블링크드 리스트 

	while (1)
	{
		n = get_input();

		if (n == -1)
			break;

		c.push_back(n);
	}
}



int main()
{
	CHRONOMETRY(using_cpp_vector);
	CHRONOMETRY(using_cpp_list);
}

