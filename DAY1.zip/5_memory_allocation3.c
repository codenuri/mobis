#include "counter.h"
#include <stdlib.h>

const int count = 10000000;

void ex1()
{
	int x[10];
	for (int i = 0; i < count; i++)
	{
		x[0] = 0;
	}
}

void ex2()
{
	int* x = (int*)malloc(sizeof(int)*10);
	
	for (int i = 0; i < count; i++)
	{
		x[0] = 0;
	}
}

int main()
{

	CHRONOMETRY(ex1);
	CHRONOMETRY(ex2);
}




