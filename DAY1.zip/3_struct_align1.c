﻿#include <stdio.h>

typedef struct _packet1
{
	char cmd;
	int data;
} PACKET1;

typedef struct _packet2
{
	char cmd;
	int data;
} PACKET2;

int main()
{
	printf("%d\n", sizeof(PACKET1));
	printf("%d\n", sizeof(PACKET2));
}
