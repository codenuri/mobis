﻿// 105 page
#include "chronometry.h"

#define count 10000

int arr[count][count]; // 10000*10000 2차원 배열

void ex1()
{
	for (int i = 0; i < count; i++)
	{
		for (int j = 0; j < count; j++)
		{
			arr[i][j] = 0;
		}
	}
}

void ex2()
{
	for (int i = 0; i < count; i++)
	{
		for (int j = 0; j < count; j++)
		{
			arr[j][i] = 0;
		}
	}
}

int main()
{
	CHRONOMETRY(ex1);
	CHRONOMETRY(ex2);
}
