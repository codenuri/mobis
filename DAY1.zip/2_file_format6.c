﻿#include <stdio.h>

// 문자열 배열 vs 문자열 포인터 - 10p

int main(void)
{
	// 아래 2줄의 차이점을 생각해 보세요
    char sa[] = "Hello";  
    char* sp = "Hello";   

//    *sa = 'A'; 
//    *sp = 'A'; 
}
