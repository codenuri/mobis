﻿// 106 page
#include "chronometry.h"
#include <thread>  

const int sz = 10000000; 

long long n1 = 0;
long long n2 = 0;

void f1()
{
	for (int i = 0; i < sz; i++)
	{
		n1 += 1;
	}
}
void f2()
{
	for (int i = 0; i < sz; i++)
	{
		n2 += 1;
	}
}

void single_thread()
{
	f1();
	f2();
}


void multi__thread()
{
	std::thread t1(f1);
	std::thread t2(f2);
	t1.join();
	t2.join();
}

int main()
{
	CHRONOMETRY(single_thread);
	CHRONOMETRY(multi__thread);
}
