﻿#include <stdio.h>

int main()
{
	int cnt = 0;

	printf("학생수를 입력해 주세요 >> ");
	scanf("%d", &cnt);

	// 3. 실행시간에 입력된 학생수 만큼 다시 점수를 입력 받아야 합니다.
 	int score[cnt];  // ?


}




// 배열의 크기로 변수 사용
// C89 문법 : 안됨
// C99 문법 : 가능.. 
// 단, gcc 는 지원하는데, visual studio 지원 안됨.
