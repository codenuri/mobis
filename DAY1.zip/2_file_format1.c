﻿#include <stdio.h>

// 전역변수의 초기값
int x = 0x99999999;
int y = 0x10203040;
int z = 0x90807060;

int main()
{
	printf("%x, %x, %x\n", x, y, z);
}
