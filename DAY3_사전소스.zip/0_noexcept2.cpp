#include <iostream>
#include <string>

class People
{
public:
	std::string name;
	int   age;
public:
	People(const std::string& s, int a)	: name(s), age(a), address(addr)
	{
	}

};

int main()
{
	People p1("kim", 20);
}





