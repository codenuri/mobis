#include <iostream>
#include <algorithm>
#include <vector>

int main()
{
	std::vector<int> v = { 4,5,6,1,2,3,7,8,9,0 };

	auto ret1 = std::find(v.begin(), v.end(), 3);
}