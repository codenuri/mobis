#include <iostream>
#include <string>
#include <string_view>

void f(std::string s)
{
	
}

int main()
{
	std::string s = "sfjsdjflsdjflsjlfks";

	f(s);
}