#include <iostream>

void f1() {}
void f2() {}
				
void f3() {}	
void f4() {}	

int main()
{
	bool b1 = noexcept( f1() );

}
