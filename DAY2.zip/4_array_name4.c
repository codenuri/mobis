﻿#include <stdio.h>

// 메모리와 변수의 타입
// => 모든 타입의 포인터 변수는 크기가 동일하다.

int main()
{
	int n = 0x11223344;

	int*  p1 = &n;
	char* p2 = &n;

	printf("%x\n", *p1);
	printf("%x\n", *p2);

	// n을 char[2][2] 배열로 접근하고 싶다.


	
	
}