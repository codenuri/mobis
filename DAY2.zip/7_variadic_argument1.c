void f1() {}
void f2(int a) {}
void f3(...) {}

int main()
{
	f1();
//	f2();
	f3();
}