#include <stdio.h>

// 매크로 함수의 장점. 

#define SQUARE(x) x * x

int main()
{
	int    ret1 = SQUARE(3);
	double ret2 = SQUARE(3.3);

	int n = 3;
	int ret3 = SQUARE(n);

	printf("%d\n", ret3);

}