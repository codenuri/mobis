#include <stdio.h>

// godbolt.org 에서 아래 코드의 어셈블리 코드를 확인해 보세요

void f1()
{
}

__attribute__((naked))
void f2()
{
}

int main()
{
}