#include <stdio.h>

int foo()
{
	return 10;
}

int main()
{
	int n = 0; 
	
	n = foo();

	printf("%d\n", n);
}