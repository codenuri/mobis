﻿// list.h
#pragma once

// ?듭떖 : ?꾨옒 肄붾뱶???곗씠????녾퀬, ?ㅼ쭅 list ???몃뱶留?議곗옉 ?⑸땲??

typedef struct _node
{
	struct _node* prev;
	struct _node* next;
} NODE;

// ?붾? ?몃뱶 珥덇린??
void init_list(NODE* head)
{
	head->next = head;
	head->prev = head;
}

void __insert_node(NODE* temp, NODE* prev, NODE* next)
{
	temp->prev = prev;
	temp->next = next;

	prev->next = temp;
	next->prev = temp;
}

void insert_front(NODE* node, NODE* head)
{
	__insert_node(node, head, head->next);

}
void insert_back(NODE* node, NODE* head)
{
	__insert_node(node, head->prev, head);
}
