#include <stdio.h>

// 멀티 라인 매크로 기술

#define PRESS()	  printf("press enter"); getchar(); 

int main()
{
	int n = 0;

	PRESS(); 

	printf("finish main\n");
}