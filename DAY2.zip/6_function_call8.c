﻿// call by value vs call by pointer

// 크기가 큰 구조체는 "call by value" 대신 "call by pointer" 가 좋습니다.
struct big
{
	int arr[100];
	char str[100];
};

void bad(struct big arg)	 // bad
{
    arg.arr[0] = 0;
}

void good(struct big* arg)	// good
{
    arg->arr[0] = 0;
}

int main()
{
	struct big b = { 0 };

	bad(b);
	good(&b);

}

