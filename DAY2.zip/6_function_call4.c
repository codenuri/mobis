#include <stdio.h>

__attribute__((naked))
void Add()
{

}

__attribute__((naked))
int asm_main()
{

	asm("ret");
}


int main()
{
	int n = asm_main();

	printf("main : %d\n", n);
}