﻿// 92 page
int main()
{
	int day = 30;
	int a = 0, b = 0, c = 0, d = 0, x = 0;

	// 1. 상수를 모아라.
	int cnt1 = 60 * day * 24 * 31;  // bad
		



	// 2. 표현식을 단순하게.
	// => 아래 2줄은 완전히 동일한 코드 입니다.
	// => ax^3 + bx^2 + cx + d
	int y1 = a * x * x * x + b * x * x + c * x + d;  // 6번의 곱셈, 3번의 덧셈
	int y2 = (((a * x + b) * x + c) * x + d);		 // 3번의 곱셈, 3번의 덧셈




	// 3. increment 
	int n1 = ++a; 
	int n2 = b++; 

	++n1;	// ?
	n1++;	// ?

	for (int i = 0; i < 10; ?? )
	{						
	}
}
