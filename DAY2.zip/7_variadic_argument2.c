#include <stdio.h>

int sum()
{
	return 0;
}

int main()
{
	int n = sum1,2,3,4,5);

	printf("%d\n", n);
}


