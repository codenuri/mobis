﻿#include <stdio.h>

// OS 소스에서 많이 볼수 있는 linked list 를 설계해 봅시다.

typedef struct _node
{
	int data;
	struct _node* prev;
	struct _node* next;
} NODE;

NODE* head = 0;

void init_node()
{
}

int main()
{
	init_node();
}
