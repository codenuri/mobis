#include <stdio.h>

#define debug(msg) printf(msg)

int main()
{
	int a = 1;
	int b = 2;

	debug("message");
}

