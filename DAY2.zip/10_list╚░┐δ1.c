﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "list.h"

typedef struct _People
{
	char name[12];
	int  age;
} People;


int main()
{
	for( int i = 1; i < 10; i++)
	{
		People* p = (People*)malloc(sizeof(People));
		p->age = i;
		sprintf(p->name, "lee %d", i);		
	}
}




