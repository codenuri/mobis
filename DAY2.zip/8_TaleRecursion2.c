﻿#include "chronometry.h"

int sum1(int n)
{
	if (n == 1) return 1;
	return n + sum1(n - 1);
}

int sumTail(int n, int result)
{
	if (n == 1) return result;
	return sumTail(n - 1, result + n);
}
int sum2(int n)
{
	return sumTail(n, 1);
}
//========================================
int main()
{
	long long cnt = 10000; 

	int ret1 = sum1(cnt);
	int ret2 = sum2(cnt);

	printf("%d\n", ret1);
	printf("%d\n", ret2);
}
