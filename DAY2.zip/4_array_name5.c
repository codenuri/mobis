﻿#include <stdio.h>

void foo(int a)
{

}

int main()
{
	? p1 = &foo;
	
}