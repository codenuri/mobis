#include <stdio.h>

#define SQUARE(x) x * x
#define MAX 5

int main()
{
	int n = MAX;

	int ret = SQUARE(++n);

	printf("%d\n", ret);
}