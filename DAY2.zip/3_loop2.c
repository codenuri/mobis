﻿#include "chronometry.h"

// 루프에서는 포인터를 "dereferencing" 사용하지 말라.

// [first ~ last] 구간의 합을 s 에 담는 함수. 
void bad(int first, int last, int* s)
{
	for (int i = first; i <= last; i++)
	{
		*s += i;
	}
}

void good(int first, int last, int* s)
{

}

int main()
{
	int s1 = 0;
	int s2 = 0;

	chronometry(bad,  1, 1000000, &s1 );
	chronometry(good, 1, 1000000, &s2 );
}
